# Techmen navigation audit

| Role | Primary before → after | Account links/actions before | Collapsed account controls before → after | Palette route entries |
| --- | --- | --- | --- | --- |
| member | 5 → 5 | 6 | 9 → 5 | 37 |
| scout-lead | 5 → 5 | 6 | 9 → 5 | 37 |
| driver | 5 → 5 | 6 | 9 → 5 | 37 |
| mentor | 5 → 5 | 6 | 9 → 6 | 53 |
| admin | 5 → 5 | 6 | 9 → 6 | 57 |
| parent | 3 → 3 | 6 | 9 → 5 | 13 |
| staff-lead | 5 → 5 | 6 | 9 → 6 | 53 |
| approver | 5 → 5 | 7 | 10 → 6 | 38 |
| parent-staff | 5 → 5 | 6 | 9 → 6 | 53 |

Before link/action counts exclude the three theme radios. After counts include every collapsed branch, including the My record and Preferences disclosures. Ordinary roles now have five top-level branches; staff and the student approver have six. The earlier primary navigation and Robot/Team admin hubs were already built. The historical 15 to 20 profile buttons are not present at baseline 5aede08.

All 54 configurations passed menu/palette viewport bounds, document overflow and console checks. The gallery includes 54 before account views and 210 after account, expanded-group, Hours and palette views. Both themes at 375, 1152 and 1440.

Parameter pages use the current matching event/trip/match or an explicitly labeled chooser. The member result opens the viewer's own member page; other members are reached through Team Hours. Three private emailed token routes stay private. Search reads no team tables and grants no permission.

These are fictional fixture accounts in Chromium. Real devices, Safari, hardware NFC, production sign-in and live database policies are not established by this evidence. No new decision is needed from Mr. Pina.
